			<div id="sidebar">
			<div class="side_box">
				
        	</div>
			
				<?php if( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar') ) : ?>
			
					<div class="side_box">
						
					</div><!--//side_box-->
					
					<div class="side_box">
						
					</div><!--//side_box-->				
					
				<?php endif; ?>
			
			</div><!--//sidebar-->